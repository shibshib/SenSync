PS2Keyboard
===========

Energia port of Arduino PS2Keyboard library.

This is based on v2.4 of PJRC's Arduino PS2Keyboard library 
from here: http://www.pjrc.com/teensy/td_libs_PS2Keyboard.html

I also added a UK keyboard layout.
